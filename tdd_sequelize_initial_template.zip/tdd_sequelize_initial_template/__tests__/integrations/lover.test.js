import request from 'supertest';
import app from '../../src/app';

import truncate from '../utils/truncate';

describe('Lover', () => {
  it('deve ser adicionado à base de dados', async () => {
    beforeEach(async () => {
      await truncate();
    });

    const response = await request(app)
      .post('/lovers')
      .send({
        name: 'Alisson Gabriel dos Santos',
        loves: 'Jesus',
      });

    expect(response.body).toHaveProperty('id');
  });
});
