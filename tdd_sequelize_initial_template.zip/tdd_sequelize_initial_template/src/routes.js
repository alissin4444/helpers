import { Router } from 'express';

import LoverController from './app/controllers/LoverController';

const routes = new Router();

routes.post('/lovers', LoverController.store);

export default routes;
