import Lover from '../models/Lover';

class LoverController {
  async store(req, res) {
    const lover = await Lover.create(req.body);
    return res.json(lover);
  }
}

export default new LoverController();
