// REQUISITOS NÃO FUNCIONAIS
// - O sistema deve utilizar como autenticação o json-web-token(JWT)
