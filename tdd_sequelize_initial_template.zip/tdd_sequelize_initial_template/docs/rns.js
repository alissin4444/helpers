// REGRAS DE NEGÓCIOS
// - Um lover deve possuir um name e seu(s) "loves"
