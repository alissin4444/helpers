const store = {
  lovers: [
    {
      name: 'Alisson Gabriel dos Santos',
      loves: ['Apple', 'Banana', 'Watermelon'],
    },
  ],
};
