const globalApp = new Vue({
	el: "#globalVue",
	data: {
		// userStorage: {
		// 	token: "",
		// 	nome: "",
		// 	nivel_perfil: ""
		// }
	},
	methods: {
		sair: function() {
			// localStorage.removeItem('token');
			// localStorage.removeItem('nome');
			// localStorage.removeItem('nivel_perfil');
			window.location.href = "../../";
		},
	},
	mounted() {
		// if(localStorage.token) {
		// 	// Dados do user
		// 	this.userStorage.token = localStorage.token;
		// 	this.userStorage.nome = localStorage.nome;
		// 	this.userStorage.nivel_perfil = localStorage.nivel_perfil;
		// } 
		// else {
		// 	window.location.href = "../../";
		// }
	}
});