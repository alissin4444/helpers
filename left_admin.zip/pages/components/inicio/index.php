<?php 
    include("../../layouts/top_imports_global.php");
?>

<!-- Locais imports -->

<?php
    include("../../layouts/top.php");
    include("../../layouts/modals.php");
    include("../../layouts/left.php");
?>
            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">
                    
                    <!-- localVue -->
                    <div id="localVue">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Login</a></li>
                                            <li class="breadcrumb-item active">Starter</li>
                                        </ol>
                                    </div>
                                    <div>
                                        <h4 class="page-title">STARTER</h4>
                                    </div>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title -->

                        <!-- Feedback -->
                        <div v-if="feedback.status">
                            <div v-if="feedback.type === 'success'">
                                <div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    {{ feedback.content }}
                                </div>
                            </div>
                            <div v-else>
                                <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    {{ feedback.content }}
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <p>Javascript can open the door. GO</p>
                        </div>

                    </div>
                    <!-- END localVue -->

                    <!-- Local Vue Scripts -->
                    <script src="./index.js"></script>
                </div> <!-- container -->

            </div> <!-- content -->

<?php include("../../layouts/bot.php"); ?>
    
<!-- Local imports -->

<?php include("../../layouts/bot_imports_global.php") ?>