const localApp = new Vue({
    el: "#localVue",
    data: {
        feedback: {
            status: false, 
            type: "",
            content: ""
        }
    },
    mounted() {
        // Dados do feedback
        if(localStorage.feedback) {
            data_feedback = JSON.parse(localStorage.getItem('feedback'));
            this.feedback.status = true,
            this.feedback.type = data_feedback.type;
            this.feedback.content = data_feedback.content;
            localStorage.removeItem('feedback');
        }
    }
});