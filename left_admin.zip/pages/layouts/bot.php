                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                2020 &copy; Desenvolvido por <a href="#">Alissin Santos</a> 
                            </div>
                            <div class="col-md-6">
                                <div class="text-md-right footer-links d-none d-sm-block">
                                    <a href="javascript:void(0);">Sobre</a>
                                    <a href="javascript:void(0);">Entrar em contato</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>
            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->
    

    <!-- Global Vue App Scripts -->
    <script src="../../assets/js/global_vue.js"></script>

    <!-- Vendor js -->
    <script src="../../assets/js/vendor.min.js"></script>

    <script src="../../assets/libs/moment/moment.min.js"></script>
    <script src="../../assets/libs/jquery-scrollto/jquery.scrollTo.min.js"></script>
    
    <!-- App js-->
    <script src="../../assets/js/app.min.js"></script>
