<!DOCTYPE html>
<html lang="pt-br">
    
<!-- Desenvolvido por Alissin Santos -->
    <head>
        <meta charset="utf-8" />
        <title>SYSTEM TITLE</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Descrition is here" name="description" />
        <meta content="Alissin Santos" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        
        <!-- App css -->
        <link href="../../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="../../assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="../../assets/css/app.min.css" rel="stylesheet" type="text/css" />

        <!-- CDN VUEJS -->
        <script src="https://cdn.jsdelivr.net/npm/vue"></script>

        <!-- AXIOS CDN -->
        <script src="https://unpkg.com/axios/dist/axios.min.js"></script>