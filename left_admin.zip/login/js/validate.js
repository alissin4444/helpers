var app = new Vue({
	el: "#app",
	data: {
		display_response: false,
		display_spinner: false,
		display_validate: false,
		response: "",
		validate_content: "",
		email: "",
		senha: "",
	},
	mounted() {
		// if(localStorage.token) {
		// 	window.location.href = "./pages/components/inicio";
		// }
	},
	methods: {
		entrar: async function() {
			window.location.href = "./pages/components/inicio";
			// if(this.email.length < 10 || this.email.includes("@") == false) {
			// 	this.validate_content = "Preencha o email corretamente";
			// 	this.display_validate = true;
			// } else if(this.senha.length < 8) {
			// 	this.validate_content = "A senha deve conter ao menos 8 caracteres";
			// 	this.display_validate = true;
			// } else {
			// 	this.display_validate = false;
			// 	this.display_spinner = true;
			// 	email = this.email;
			// 	password = this.senha;
			// 	await axios.post('http://127.0.0.1:3333/session', { email, password })
			// 	.then(async response => {
			// 		await axios.get("http://127.0.0.1:3333/users/profile",  { 
			// 			headers: {"Authorization" : `Bearer ${response.data.token}`} 
			// 		}).then(async response => {
			// 			const data = response.data;
			// 			if(data.ativo !== true) {
			// 				this.display_spinner = false;
			// 				this.validate_content = "Conta desativada";
			// 				this.display_validate = true;
			// 				localStorage.removeItem('token');
			// 				return false;
			// 			}
			// 			localStorage.nome = data.nome;
			// 			localStorage.nivel_perfil = data.nivel_perfil;
			// 			localStorage.foto = data.perfil.foto ? data.perfil.foto : "images/img.png";
						
			// 		})
			// 		localStorage.token = response.data.token;
			// 		window.location.href = "./pages/components/inicio";
			// 	})
			// 	.catch(err => {
			// 		const agent = err.response.data[0].field;
			// 		switch (agent) {
			//           case 'email': 
			//             this.display_spinner = false;
			//             this.validate_content = "Email incorreto";
			//             this.display_validate = true;
			//             break
			//           case 'password':
			//           	this.display_spinner = false;
			//             this.validate_content = "Senha incorreta";
			//             this.display_validate = true;
			//             break
			//           default:
			//             return false;
			//         }
			// 	})
			// }
		}
	}
});