/* eslint-disable react/no-multi-comp */
/* eslint-disable react/display-name */
import React from 'react';
import {
  FaHome,
  FaCalendarAlt,
  FaCommentMedical,
  FaFileMedical,
  FaUsers,
  FaUserMd,
  FaUserNurse,
  FaFemale,
  FaUserGraduate,
  FaComments,
  FaUserAstronaut
} from 'react-icons/fa';

export default [
  {
    title: 'PÁGINAS',
    pages: [
      {
        title: 'Início',
        href: '/app',
        icon: FaHome
      },
      {
        title: 'Agendamentos',
        href: '/agendamentos',
        icon: FaCalendarAlt
      },
      {
        title: 'Triagens',
        href: '/triagens',
        icon: FaCommentMedical
      },
      {
        title: 'Consultas',
        href: '/consultas',
        icon: FaFileMedical
      }
    ]
  },
  {
    title: 'Usuários',
    pages: [
      {
        title: 'Pacientes',
        href: '/pacientes',
        icon: FaUsers
      },
      {
        title: 'Gerals',
        href: '/gerals',
        icon: FaUserAstronaut
      },
      {
        title: 'Médicos',
        href: '/medicos',
        icon: FaUserMd
      },
      {
        title: 'Enfermeiras',
        href: '/enfermeiras',
        icon: FaUserNurse
      },
      {
        title: 'Secretárias',
        href: '/secretarias',
        icon: FaFemale
      },
      {
        title: 'Estudantes',
        href: '/estudantes',
        icon: FaUserGraduate
      }
    ]
  },
  {
    title: 'Outros',
    pages: [
      {
        title: 'Sugestões',
        href: '/sugestoes',
        icon: FaComments
      }
    ]
  }
];
