/* eslint-disable no-unused-vars */
import React, { useState, useRef, useEffect } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/styles';
import {
  AppBar,
  Button,
  IconButton,
  Toolbar,
  Hidden,
  Menu,
  MenuItem
} from '@material-ui/core';

import {
  FaUserCircle,
  FaPencilAlt,
  FaSignOutAlt,
  FaUsers,
  FaUserMd,
  FaUserNurse,
  FaFemale,
  FaUserGraduate,
  FaUserAstronaut
} from 'react-icons/fa';
import Add from '@material-ui/icons/Add';
import { KeyboardArrowDown } from '@material-ui/icons/';
import MenuIcon from '@material-ui/icons/Menu';

import axios from 'utils/axios';
import useRouter from 'utils/useRouter';

const TopBar = props => {
  const { onOpenNavBarMobile, className, ...rest } = props;

  const classes = useStyles();
  const { history } = useRouter();

  const handleLogout = () => {
    history.push('/auth/login');
    // dispatch(logout());
  };

  const [menuLogout, setMenuLogout] = useState(null);

  const handleClickLogoutMenu = event => {
    setMenuLogout(event.currentTarget);
  };

  const handleClickLogoutMenuClose = () => {
    setMenuLogout(null);
  };

  const [menuAddUser, setMenuAddUser] = useState(null);

  const handleClickAddUser = event => {
    setMenuAddUser(event.currentTarget);
  };

  const handleClickAddUserClose = () => {
    setMenuAddUser(null);
  };

  return (
    <AppBar
      {...rest}
      className={clsx(classes.root, className)}
      color="primary"
    >
      <Toolbar className={classes.flexGrow}>
        <div className={classes.actionContainer}>
          <div className={classes.logoContainer}>
            <RouterLink to="/">
              <img
                alt="Logo"
                src="http://zhealth.com.br/zhealth_new/pages/assets/images/logo-light.png"
                width="125"
              />
            </RouterLink>
          </div>
          <Hidden smDown>
            <div className={classes.actions}>
              <>
                <Button
                  className={classes.buttonAction}
                  onClick={handleClickAddUser}
                  size="small"
                >
                  <Add
                    className={classes.trialIcon}
                    fontSize="small"
                  />
                  Adicionar Usuário
                </Button>
                <Menu
                  anchorEl={menuAddUser}
                  anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'center'
                  }}
                  id="simple-menu"
                  keepMounted
                  onClose={handleClickAddUserClose}
                  open={Boolean(menuAddUser)}
                  style={{
                    marginTop: 38,
                    marginLeft: 40
                  }}
                  transformOrigin={{
                    vertical: 'top',
                    horizontal: 'center'
                  }}
                >
                  <MenuItem
                    className={classes.addUserMenuItem}
                    onClick={handleClickAddUserClose}
                  >
                    <FaUsers className={classes.menuAddUserIcon} />
                    <span className={classes.menuItemText}>Paciente</span>
                  </MenuItem>
                  <MenuItem
                    className={classes.addUserMenuItem}
                    onClick={handleClickAddUserClose}
                  >
                    <FaUserAstronaut className={classes.menuAddUserIcon} />
                    <span className={classes.menuItemText}>Geral</span>
                  </MenuItem>
                  <MenuItem
                    className={classes.addUserMenuItem}
                    onClick={handleClickAddUserClose}
                  >
                    <FaUserMd className={classes.menuAddUserIcon} />
                    <span className={classes.menuItemText}>Médico</span>
                  </MenuItem>
                  <MenuItem
                    className={classes.addUserMenuItem}
                    onClick={handleClickAddUserClose}
                  >
                    <FaUserNurse className={classes.menuAddUserIcon} />
                    <span className={classes.menuItemText}>Enfermeira</span>
                  </MenuItem>
                  <MenuItem
                    className={classes.addUserMenuItem}
                    onClick={handleClickAddUserClose}
                  >
                    <FaFemale className={classes.menuAddUserIcon} />
                    <span className={classes.menuItemText}>Secretária</span>
                  </MenuItem>
                  <MenuItem
                    className={classes.addUserMenuItem}
                    onClick={handleClickAddUserClose}
                  >
                    <FaUserGraduate className={classes.menuAddUserIcon} />
                    <span className={classes.menuItemText}>Estudante</span>
                  </MenuItem>
                </Menu>
              </>
            </div>
          </Hidden>
        </div>
        <Hidden mdDown>
          <>
            <Button
              className={classes.logoutButton}
              color="inherit"
              onClick={handleClickLogoutMenu}
            >
              <span>Alisson Santos</span>
              <KeyboardArrowDown />
            </Button>
            <Menu
              anchorEl={menuLogout}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'right'
              }}
              id="simple-menu"
              keepMounted
              onClose={handleClickLogoutMenuClose}
              open={Boolean(menuLogout)}
              style={{
                marginTop: 38,
                marginRight: 20
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'right'
              }}
            >
              <MenuItem onClick={handleClickLogoutMenuClose}>
                <FaUserCircle className={classes.menuLogoutIcon} />
                <span className={classes.menuItemText}>Perfil</span>
              </MenuItem>
              <MenuItem onClick={handleClickLogoutMenuClose}>
                <FaPencilAlt className={classes.menuLogoutIcon} />
                <span className={classes.menuItemText}>Alterar dados</span>
              </MenuItem>
              <MenuItem onClick={handleLogout}>
                <FaSignOutAlt className={classes.menuLogoutIcon} />
                <span className={classes.menuItemText}>Sair</span>
              </MenuItem>
            </Menu>
          </>
        </Hidden>
        <Hidden lgUp>
          <IconButton
            color="inherit"
            onClick={onOpenNavBarMobile}
          >
            <MenuIcon />
          </IconButton>
        </Hidden>
      </Toolbar>
    </AppBar>
  );
};

TopBar.propTypes = {
  className: PropTypes.string,
  onOpenNavBarMobile: PropTypes.func
};

const useStyles = makeStyles(theme => ({
  root: {
    boxShadow: 'none'
  },
  flexGrow: {
    flexGrow: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    margin: 0,
    padding: 0
  },
  logoContainer: {
    width: 240,
    padding: '0 20px',
    display: 'flex',
    [theme.breakpoints.up('lg')]: {
      justifyContent: 'center'
    }
  },
  actionContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-start',
    flex: 1
  },
  actions: {
    marginLeft: theme.spacing(2)
  },
  buttonAction: {
    borderRadius: 0,
    padding: '22px 11px',
    textTransform: 'none',
    color: theme.palette.white
  },
  trialIcon: {
    marginRight: theme.spacing(1)
  },
  logoutButton: {
    textTransform: 'none',
    borderRadius: 0,
    padding: '22px 11px',
    marginRight: 20,
    '& span': {
      fontSize: 12
    }
  },
  addUserMenuItem: {
    paddingRight: 120
  },
  menuAddUserIcon: {
    color: theme.palette.muted,
    fontSize: 20,
    marginRight: 20
  },
  menuLogoutIcon: {
    color: theme.palette.muted,
    fontSize: 16,
    marginRight: 16
  },
  menuItemText: {
    fontSize: 14
  }
}));

export default TopBar;
