/* eslint-disable react/no-multi-comp */
/* eslint-disable react/display-name */
import React, { lazy } from 'react';
import { Redirect } from 'react-router-dom';

import AuthLayout from './layouts/Auth';
import ErrorLayout from './layouts/Error';
import DashboardLayout from './layouts/Dashboard';
import Inicio from './views/Inicio';

const routes = [
  {
    path: '/',
    exact: true,
    component: () => <Redirect to="/app" />
  },
  {
    path: '/autenticacao',
    component: AuthLayout,
    routes: [
      {
        path: '/autenticacao/entrar',
        exact: true,
        component: lazy(() => import('views/Login'))
      },
      {
        component: () => <Redirect to="/erros/404" />
      }
    ]
  },
  {
    path: '/erros',
    component: ErrorLayout,
    routes: [
      {
        path: '/erros/404',
        exact: true,
        component: lazy(() => import('views/Error404'))
      },
      {
        component: () => <Redirect to="/erro/404" />
      }
    ]
  },
  {
    route: '*',
    component: DashboardLayout,
    routes: [
      {
        path: '/app',
        exact: true,
        component: Inicio
      },
      {
        path: '/blanc',
        exact: true,
        component: lazy(() => import('views/GettingStarted'))
      },
      {
        component: () => <Redirect to="/erros/404" />
      }
    ]
  }
];

export default routes;
