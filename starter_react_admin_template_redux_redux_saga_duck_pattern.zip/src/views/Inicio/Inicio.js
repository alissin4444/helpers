import React, { useEffect } from 'react';
import { makeStyles } from '@material-ui/styles';

import { Button } from '@material-ui/core';

import { Page } from 'components';
import { Header } from './components';

import { useSelector, useDispatch } from 'react-redux';
import { Creators as PacienteActions } from '../../store/ducks/pacientes';

const Inicio = () => {
  const dispatch = useDispatch();
  const pacientes = useSelector(state => state.pacientes);

  useEffect(() => {
    setTimeout(() => {
      dispatch(PacienteActions.addPacienteRequest('Lehzinha Monteiro'));
    }, 2000);
    setTimeout(() => {
      dispatch(PacienteActions.addPacienteRequest('Brazonzinho Otario'));
    }, 3000);
  }, []);

  const classes = useStyles();
  return (
    <>
      <Page
        className={classes.root}
        title="Início"
      >
        <Header />
        <ul>
          {pacientes.map(paciente => (
            <li key={paciente}>{paciente}</li>
          ))}
        </ul>
      </Page>
    </>
  );
};

const useStyles = makeStyles(theme => ({
  root: {
    width: theme.breakpoints.values.lg,
    maxWidth: '100%',
    margin: '0 auto',
    padding: theme.spacing(3)
  },
  statistics: {
    marginTop: theme.spacing(3)
  },
  notifications: {
    marginTop: theme.spacing(6)
  },
  projects: {
    marginTop: theme.spacing(6)
  },
  todos: {
    marginTop: theme.spacing(6)
  }
}));

export default Inicio;
