export { default } from './Inicio';
