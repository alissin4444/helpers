import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/styles';
import { Typography, Divider, colors } from '@material-ui/core';

import { Page } from 'components';

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3, 3, 6, 3)
  },
  divider: {
    backgroundColor: colors.grey[300],
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(3)
  }
}));

const GettingStarted = () => {
  const classes = useStyles();
  return (
    <Page
      className={classes.root}
      title="Getting Started"
    >
      <Typography
        gutterBottom
        variant="overline"
      >
        Alissin Santos
      </Typography>
      <Typography variant="h3">Getting Started</Typography>
      <Divider className={classes.divider} />
    </Page>
  );
};

export default GettingStarted;
