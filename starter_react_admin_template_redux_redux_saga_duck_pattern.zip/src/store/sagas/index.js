import { all, takeLatest } from 'redux-saga/effects';

import { addPacienteRequest } from './pacientes';

import { PacienteTypes } from '../ducks/pacientes';

export default function* rootSaga() {
  return yield all([
    takeLatest(PacienteTypes.ADD_PACIENTE_REQUEST, addPacienteRequest)
  ]);
}
