import { put } from 'redux-saga/effects';

import { Creators as PacienteActions } from '../ducks/pacientes';

export function* addPacienteRequest({ paciente }) {
  // const response = yield call(api.get, `/products/${id}`);
  yield put(PacienteActions.addPacienteSuccess(paciente));
}
