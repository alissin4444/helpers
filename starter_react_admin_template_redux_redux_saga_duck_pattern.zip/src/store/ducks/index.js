import { combineReducers } from 'redux';

import pacientes from './pacientes';

export default combineReducers({
  pacientes
});
