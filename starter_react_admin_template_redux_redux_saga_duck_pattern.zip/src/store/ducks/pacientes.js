import produce from 'immer';

import { createActions, createReducer } from 'reduxsauce';

export const { Types, Creators } = createActions({
  addPacienteRequest: ['paciente'],
  addPacienteSuccess: ['paciente']
});

export const PacienteTypes = Types;

const INITIAL_STATE = ['Alissin Santos', 'Karininha Lima'];

const addPacienteSuccess = (state = INITIAL_STATE, action) =>
  produce(state, draft => {
    draft.push(action.paciente);
  });

export default createReducer(INITIAL_STATE, {
  [Types.ADD_PACIENTE_SUCCESS]: addPacienteSuccess
});
