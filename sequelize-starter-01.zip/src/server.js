import app from './app';

app.listen(3333);