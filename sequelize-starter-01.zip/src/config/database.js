module.exports = {
  dialect: "postgres",
  host: "HOST",
  username: "USERDATABASE",
  password: "PASSWORD",
  database: "USERDATABASE",
  define: {
    timestamps: true,
    underscored: true,
    underscoredAll: true
  }
};
