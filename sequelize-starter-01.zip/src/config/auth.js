export default {
  secret: "39c571b7ccdddb4096ad2d3e1ad63a0d",
  expiresIn: "30d"
  // expiresIn: '7d' 300
};
