// Register.vue

<template>
    <div>
        Register
    </div>
</template>



<script>
export default {
    
}
</script>