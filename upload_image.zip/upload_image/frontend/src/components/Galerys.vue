// Images.vue

<template>
	<div>
		<h1 class="page-title">ADONIS VUE GALERY</h1>
		<div class="container">
			<div v-for="imagem in imagens" v-bind:key="imagem.id" class="imagem">
				<div class="imagem-title-container">
					<div><label>{{imagem.nome}}</label></div>
					<div class="imagem-title-actions">
						<div>EDITAR</div>
						<div>APAGAR</div>
					</div>
				</div>
				<div class="imagem-body">
					<img v-bind:src="imagem.foto" width="600px" />
				</div>
			</div>
		</div>
	</div>
</template>


<script>
import axios from "axios";
export default {
	name: "Galerys",
	data() {
		return { 
		  	imagens: []
		}
	},
	async mounted() {
		await axios.get("http://127.0.0.1:3333/images").then(response => {
			this.imagens = response.data;
		})
	}
}
</script>

<style type="text/css" scoped>
	.page-title {
		color: #555;
		font-size: 25px;
		font-family: "Arial", sans-serif;
		margin-bottom: 10px;
	}
	.container {
		background-color: #eee;
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: flex-start;
		padding: 15px;
		width: 600px;
	}
	.imagem-title-container {
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: space-between;
		width: 600px;
	}
	.imagem-title-actions {
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: space-between;
		width: 150px;
	}
	label {
		text-align: left;
		margin-bottom: 5px;
		color: #888;
		font-size: 24px;
		font-family: "Arial", sans-serif;
	}
	img {
		border-bottom-right-radius: 4px;
		border-bottom-left-radius: 4px;
	}
	.imagem {
		margin-bottom: 20px;
	}
</style>	