<template>
    <div>
        Student ID is: {{ $route.params.id}}
        AND this data is {{ name }} {{ lastName }}
    </div>
</template>

<script>
export default {
  name: "Student",
  data() {
	  return { 
	  	name: "Alissin",
	  	lastName: "Santos" 
		}
  }
}
</script>