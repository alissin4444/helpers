// Images.vue

<template>
        <form class="container">
        	<h1 class="page-title">ADONIS VUE UPLOAD</h1>
        	<form class="forms" @submit="handleSubmit">
        		<label>Título</label>
	        	<input v-model="nome" type="text" placeholder="Digite o título" />
	        	<input @change="handleFile($event)" type="file" accept="image/*" placeholder="Selecione uma imagem" />
	        	<input type="submit" value="CADASTRAR" />
        	</form>
        </form>
</template>


<script>
import axios from "axios";	
export default {
	name: "Images",
	data() {
		return { 
		  	nome: "",
		  	foto: ""
		}
	},
	methods: {
		handleSubmit: async function(event) {
			event.preventDefault();

			let formData = new FormData();
			formData.append("foto", this.foto);

			await axios.post('http://127.0.0.1:3333/uploads', formData, { headers: { 'Content-Type': 'multipart/form-data' }})
			.then(async response => {
				await axios.post('http://127.0.0.1:3333/images', {
					nome: this.nome,
					foto: response.data.url
				}).then(response => {
					this.$router.push("/galerys");
				})
			}).catch(err => console.log(err))

		},
		handleFile(event) {
			this.foto = event.target.files[0];
		}
	},
}
</script>

<style type="text/css" scoped>
	.container {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: flex-start;
		padding: 10px;
		margin: 20px;
		width: 100%;
		max-width: 600px;
		border-radius: 8px;
		background-color: #eee;
	}
	.page-title {
		color: #555;
		font-size: 25px;
		font-family: "Arial", sans-serif;
		margin-bottom: 40px;
	}
	input[type=submit] {
		margin-top: 20px;
		color: #555;
		background-color: #fff;
		border: none;
		border-radius: 4px;
		padding: 8px;
		cursor: pointer;
		outline: none;
	}
	input[type=text] {
		color: #555;
		background-color: #fff;
		border: 1px solid #ddd;
		border-radius: 4px;
		padding: 8px;
		outline: none;
		margin-bottom: 10px;		
	}
	.forms {
		width: 60%;
		display: flex;
		flex-direction: column;
	}
	label {
		text-align: left;
		margin-bottom: 5px;
		color: #888;
		font-size: 15px;
		font-family: "Arial", sans-serif;
	}
</style>	