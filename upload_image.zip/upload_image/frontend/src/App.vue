<template>
  <div id="app">
    <nav class="nav">
      <div class="logo">
        <router-link class="navItem" to='/'><b>IMAGE UPLOAD</b></router-link> 
      </div>
      <div>
        <router-link class="navItem" to='/'>Home</router-link>
        <router-link class="navItem" to='/register'>Register</router-link>
        <router-link class="navItem" to='/login'>Login</router-link>
        <router-link class="navItem" to='/images'>Upload</router-link>
        <router-link class="navItem" to='/galerys'>Galeria</router-link>
      </div>
    </nav>
    <div class="container">
      <router-view />
    </div>
  </div>
</template>

<script>
  
</script>

<style type="text/css">
  body {
    margin: 0;
    padding: 0;
    background-color: #eee;
  }
  a {
    text-decoration: none;
  }
	.nav {
		display: flex;
		align-items:  center;
		justify-content: space-between;
    padding: 20px;
    background-color: #fff;
	}
	.navItem {
		margin: 0 20px;
    color: #888;
    font-size: 18px;
    font-family: "Arial", sans-serif;
	}
  .logo {
    color: #555;
    font-size: 18px;
    font-family: "Arial", sans-serif;
  }
  .container {
    margin-top: 15px;
    background-color: #fff;
    display: flex;
    min-height: 80vh; 
    justify-content: center;
    align-items: center;
  }
</style>