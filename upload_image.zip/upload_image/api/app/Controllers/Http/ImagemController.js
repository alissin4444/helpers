'use strict'

const Cloudinary = use('App/Services/Cloudinary');
const Imagem = use('App/Models/Imagem');


class ImagemController {

    async index ({ request, response }) {
      return await Imagem.all();
    }

    async store ({ request, response }) {
        const { nome, foto } = request.all();

        const imagem = await Imagem.create({
          nome, foto
        });

        return imagem;
    }

}

module.exports = ImagemController