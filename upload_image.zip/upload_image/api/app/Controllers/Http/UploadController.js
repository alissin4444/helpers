'use strict'

const Cloudinary = use('App/Services/Cloudinary');


class ImagemController {

    async store ({ request, response }) {
        const foto = request.file('foto', {
            types: ['image'],
            size: '2mb'
        });

        // Valido o tipo de arquivo
        if(foto.type !== "image") {
            return response.unauthorized({ message: "Arquivo não permitido", actor: "FILE" })
        } else if(foto.size > 2000000) { // Valido os 2mb
            return response.unauthorized({ message: "Tamanho permitido excedido", actor: "SIZE" });
        }

        const imagem_path = await Cloudinary.upload(foto);

        return response.json(imagem_path);
    }

}

module.exports = ImagemController