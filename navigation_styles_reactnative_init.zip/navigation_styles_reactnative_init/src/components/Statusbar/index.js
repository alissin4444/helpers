import React from "react";

import { View } from "react-native";
import Constants from "expo-constants";

import Theme from "../../configs/Theme";

export default function Statusbar() {
  return (
    <View
      style={{
        backgroundColor: `${Theme.primary}`,
        height: Constants.statusBarHeight
      }}
      barStyle="dark-content"
    />
  );
}
