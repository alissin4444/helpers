import React from "react";

import { Container, Title } from "./styles";

export default function Inicio({ navigation }) {
  return (
    <Container>
      <Title>Inicio</Title>
    </Container>
  );
}
