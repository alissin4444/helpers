import styled from "styled-components/native";
import { darken } from "polished";

import Theme from "../../configs/Theme";

export const Container = styled.View`
  background: ${darken(0.08, Theme.background.tint)};
  flex: 1;
  align-items: center;
  justify-content: center;
`;

export const Title = styled.Text`
  color: ${Theme.typography};
  font-size: 20px;
`;
