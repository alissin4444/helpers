import { createAppContainer, createSwitchNavigator } from "react-navigation";

import Inicio from "./pages/Inicio";

const ROUTES = createSwitchNavigator({
  Inicio,
});

export default createAppContainer(ROUTES);
