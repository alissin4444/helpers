const Theme = {
  primary: "#6c5ce7",
  background: {
    shade: "#04020f",
    tint: "#ecf1f8"
  },
  typography: "#333333"
};

export default Theme;
