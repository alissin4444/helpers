import React from "react";

import Routes from "./src/routes";

import Statusbar from "./src/components/Statusbar";

export default function App() {
  return (
    <>
      <Statusbar />
      <Routes />
    </>
  );
}
