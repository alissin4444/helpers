const localApp = new Vue({
  el: "#localVue",
  data: {
    feedback: {
      status: false,
      type: "",
      content: ""
    },
    events: [],
    date: null
  },
  methods: {},
  async mounted() {
    // Dados do feedback
    if (localStorage.feedback) {
      data_feedback = JSON.parse(localStorage.getItem("feedback"));
      (this.feedback.status = true), (this.feedback.type = data_feedback.type);
      this.feedback.content = data_feedback.content;
      localStorage.removeItem("feedback");
    }

    var calendar = new FullCalendar.Calendar(
      document.getElementById("calendar"),
      {
        plugins: ["interaction", "dayGrid", "list"],
        header: {
          right: "prev, next today",
          center: "title",
          left: ""
        },
        locale: "pt",
        buttonIcons: true, // show the prev/next text
        weekNumbers: true,
        navLinks: true, // can click day/week names to navigate views
        editable: true,
        eventLimit: false, // allow "more" link when too many events
        eventSources: [
          {
            url: "http://127.0.0.1:3333/todos"
          }
        ],
        eventClick: function(info) {
          const data = {
            id: info.event.id,
            title: info.event.title,
            color: info.event.backgroundColor,
            textColor: info.event.textColor
          };
          console.log(data);
        }
      }
    );

    calendar.render();
  }
});
