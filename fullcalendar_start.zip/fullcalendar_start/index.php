<?php 
    include("../../layouts/top_imports_global.php");
?>

<!-- Locais imports -->
<link href='../../assets/libs/fullcalendar/packages/core/main.css' rel='stylesheet' />
<link href='../../assets/libs/fullcalendar/packages/daygrid/main.css' rel='stylesheet' />
<link href='../../assets/libs/fullcalendar/packages/timegrid/main.css' rel='stylesheet' />
<link href='../../assets/libs/fullcalendar/packages/list/main.css' rel='stylesheet' />
<script src='../../assets/libs/fullcalendar/packages/core/main.js'></script>
<script src='../../assets/libs/fullcalendar/packages/core/locales-all.js'></script>
<script src='../../assets/libs/fullcalendar/packages/interaction/main.js'></script>
<script src='../../assets/libs/fullcalendar/packages/daygrid/main.js'></script>
<script src='../../assets/libs/fullcalendar/packages/timegrid/main.js'></script>
<script src='../../assets/libs/fullcalendar/packages/list/main.js'></script>


<?php
    include("../../layouts/top.php");
    include("../../layouts/modals.php");
    include("../../layouts/left.php");
?>
            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">
                    
                    <!-- localVue -->
                    <div id="localVue">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Zhealth</a></li>
                                            <li class="breadcrumb-item active">Agendamentos</li>
                                        </ol>
                                    </div>
                                    <div>
                                        <h4 class="page-title">Agendamentos</h4>
                                    </div>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title -->

                        <!-- Feedback -->
                        <div v-if="feedback.status">
                            <div v-if="feedback.type === 'success'">
                                <div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    {{ feedback.content }}
                                </div>
                            </div>
                            <div v-else>
                                <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    {{ feedback.content }}
                                </div>
                            </div>
                        </div>

                        <div class="row d-flex justify-content-between align-items-center col-12">
                            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Agenda</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Relatórios</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Pesquisar</a>
                                </li>
                            </ul>
                            <button class="btn btn-primary btn-rounded waves-effect waves-light">Adicionar um novo agendamento</button>
                        </div>
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                <nav>
                                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                        <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Pacientes agendados</a>
                                        <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Pacientes que faltaram</a>
                                        <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Pacientes atendidos</a>
                                    </div>
                                </nav>
                                <div class="tab-content" id="nav-tabContent">
                                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                        <div id='calendar'></div>
                                    </div>
                                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                                        // Other calendary
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">...</div>
                            <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">...</div>
                        </div>

                    </div>
                    <!-- END localVue -->

                    <!-- Local Vue Scripts -->
                    <script src="./index.js"></script>
                </div> <!-- container -->

            </div> <!-- content -->

<?php include("../../layouts/bot.php"); ?>
    
<!-- Local imports -->



<?php include("../../layouts/bot_imports_global.php") ?>